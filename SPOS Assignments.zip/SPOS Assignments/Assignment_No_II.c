// write a program using fork system call to create  a process and perform following operations>
// Parent process finds maximum element from an array and child process finds minimum element from an array

#include <stdio.h>
#include <unistd.h>


int main() {
    int arr[] = {23, 45, 12, 67, 34, 89, 10};
    int n = sizeof(arr) / sizeof(arr[0]);

    pid_t pid = fork();

    if (pid < 0) {
        // Fork failed
        perror("Fork failed");
        return 1;
    }
    else if (pid == 0) {
        // Child Process: Find minimum
        int min = arr[0];
        for (int i = 1; i < n; i++) {
            if (arr[i] < min)
                min = arr[i];
        }
        printf("Child Process (PID: %d): Minimum = %d\n", getpid(), min);
    }
    else {
        // Parent Process
    
        int max = arr[0];
        for (int i = 1; i < n; i++) {
            if (arr[i] > max)
                max = arr[i];
        }
        printf("Parent Process (PID: %d): Maximum = %d\n", getpid(), max);
    }

    return 0;
}
