// Write a program using fork .parent process sory arry in ascending orde using selection sort ,
// child process sort array in descending order using insertion sort

#include <stdio.h>
#include <unistd.h>


void selectionSortAscending(int arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIdx])
                minIdx = j;
        }
        if (minIdx != i) {
            int temp = arr[i];
            arr[i] = arr[minIdx];
            arr[minIdx] = temp;
        }
    }
}

void insertionSortDescending(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
        while (j >= 0 && arr[j] < key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

void printArray(const char* msg, int arr[], int n) {
    printf("%s: ", msg);
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);
    printf("\n");
}

int main() {
    int arr[] = {45, 12, 78, 34, 89, 23};
    int n = sizeof(arr) / sizeof(arr[0]);

    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        return 1;
    }
    else if (pid == 0) {
        // Child process: Insertion Sort (Descending)
        int childArr[n];
        for (int i = 0; i < n; i++)
            childArr[i] = arr[i];

        insertionSortDescending(childArr, n);
        printArray("Child Process - Descending Order", childArr, n);
    }
    else {
        // Parent process: Selection Sort (Ascending)
 
        int parentArr[n];
        for (int i = 0; i < n; i++)
            parentArr[i] = arr[i];

        selectionSortAscending(parentArr, n);
        printArray("Parent Process - Ascending Order", parentArr, n);
    }

    return 0;
}
