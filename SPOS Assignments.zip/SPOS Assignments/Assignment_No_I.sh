DB_FILE="students.txt"

create_db() {
    if [ -f "$DB_FILE" ]; then
        echo "Database already exists."
    else
        touch "$DB_FILE"
        echo "Student database created."
    fi
}

view_db() {
    if [ ! -s "$DB_FILE" ]; then
        echo "Database is empty."
    else
        echo "RollNo, Name, Age, Branch"
        cat "$DB_FILE"
    fi
}

insert_student() {
    echo -n "Enter Roll Number: "; read roll
    echo -n "Enter Name: "; read name
    echo -n "Enter Age: "; read age
    echo -n "Enter Branch: "; read branch
    echo "$roll,$name,$age,$branch" >> "$DB_FILE"
    echo "Student added successfully."
}

update_student() {
    echo -n "Enter Roll Number to Update: "; read roll
    if grep -q "^$roll," "$DB_FILE"; then
        echo -n "Enter New Name: "; read name
        echo -n "Enter New Age: "; read age
        echo -n "Enter New Branch: "; read branch
        awk -F, -v r="$roll" -v n="$name" -v a="$age" -v b="$branch" 'BEGIN{OFS=","} $1==r {$2=n; $3=a; $4=b} {print}' "$DB_FILE" > tmp && mv tmp "$DB_FILE"
        echo "Student record updated."
    else
        echo "Student with Roll No $roll not found."
    fi
}

search_student() {
    echo -n "Enter Roll Number to Search: "; read roll
    awk -F, -v r="$roll" '$1==r {print "Found: RollNo="$1", Name="$2", Age="$3", Branch="$4}' "$DB_FILE"
}

while true; do
    echo -e "\nStudent Database Menu"
    echo "1. Create Database"
    echo "2. View All Students"
    echo "3. Insert New Student"
    echo "5. Update Student"
    echo "6. Search Student"
    echo "7. Exit"
    echo -n "Choose an option: "; read choice

    case $choice in
        1) create_db ;;
        2) view_db ;;
        3) insert_student ;;
        5) update_student ;;
        6) search_student ;;
        7) echo "Exiting..."; break ;;
        *) echo "Invalid option!" ;;
    esac
done
