#include <stdio.h>
#include <limits.h>

#define MAX 10

// Structure for each process
struct process {
    int id;
    int at; // arrival time
    int bt; // burst time
    int ct; // completion time
    int tat; // turnaround time
    int wt; // waiting time
    int rt; // remaining time
    int priority;
};

// Function to display results
void display(struct process p[], int n) {
    printf("\nID\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        p[i].tat = p[i].ct - p[i].at;
        p[i].wt = p[i].tat - p[i].bt;
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n", p[i].id, p[i].at, p[i].bt, p[i].ct, p[i].tat, p[i].wt);
    }
}

// FCFS Scheduling
void fcfs(struct process p[], int n) {
    int time = 0;
    for (int i = 0; i < n; i++) {
        if (time < p[i].at) time = p[i].at;
        time += p[i].bt;
        p[i].ct = time;
    }
    display(p, n);
}

// SJF Preemptive Scheduling
void sjf_preemptive(struct process p[], int n) {
    int time = 0, completed = 0, min, idx;
    for (int i = 0; i < n; i++) {
        p[i].rt = p[i].bt;
    }

    while (completed != n) {
        min = INT_MAX;
        idx = -1;
        for (int i = 0; i < n; i++) {
            if (p[i].at <= time && p[i].rt > 0 && p[i].rt < min) {
                min = p[i].rt;
                idx = i;
            }
        }
        if (idx == -1) {
            time++;
            continue;
        }
        p[idx].rt--;
        if (p[idx].rt == 0) {
            completed++;
            p[idx].ct = time + 1;
        }
        time++;
    }
    display(p, n);
}

// Priority Scheduling (Non-preemptive)
void priority_non_preemptive(struct process p[], int n) {
    int time = 0, completed = 0, idx;
    int done[MAX] = {0};

    while (completed < n) {
        int highest = INT_MAX;
        idx = -1;
        for (int i = 0; i < n; i++) {
            if (!done[i] && p[i].at <= time && p[i].priority < highest) {
                highest = p[i].priority;
                idx = i;
            }
        }
        if (idx == -1) {
            time++;
            continue;
        }
        time += p[idx].bt;
        p[idx].ct = time;
        done[idx] = 1;
        completed++;
    }
    display(p, n);
}

// Round Robin Scheduling
void round_robin(struct process p[], int n, int q) {
    int time = 0, completed = 0;
    int done = 0;
    for (int i = 0; i < n; i++)
        p[i].rt = p[i].bt;

    while (completed < n) {
        done = 1;
        for (int i = 0; i < n; i++) {
            if (p[i].rt > 0 && p[i].at <= time) {
                done = 0;
                if (p[i].rt > q) {
                    time += q;
                    p[i].rt -= q;
                } else {
                    time += p[i].rt;
                    p[i].ct = time;
                    p[i].rt = 0;
                    completed++;
                }
            }
        }
        if (done) time++;
    }
    display(p, n);
}

// Main program
int main() {
    struct process p[MAX];
    int n, choice, q;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    // Take input
    for (int i = 0; i < n; i++) {
        p[i].id = i + 1;
        printf("Process %d Arrival Time: ", i + 1);
        scanf("%d", &p[i].at);
        printf("Process %d Burst Time: ", i + 1);
        scanf("%d", &p[i].bt);
        printf("Process %d Priority (lower = higher priority): ", i + 1);
        scanf("%d", &p[i].priority);
    }

    // Menu
    do {
        printf("\nCPU Scheduling Algorithms:\n");
        printf("1. FCFS\n2. SJF Preemptive\n3. Priority (Non-preemptive)\n4. Round Robin\n5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        struct process temp[MAX];
        for (int i = 0; i < n; i++)
            temp[i] = p[i];

        switch (choice) {
            case 1:
                fcfs(temp, n);
                break;
            case 2:
                sjf_preemptive(temp, n);
                break;
            case 3:
                priority_non_preemptive(temp, n);
                break;
            case 4:
                printf("Enter time quantum: ");
                scanf("%d", &q);
                round_robin(temp, n, q);
                break;
            case 5:
                printf("Exiting.\n");
                break;
            default:
                printf("Invalid choice.\n");
        }
    } while (choice != 5);

    return 0;
}
