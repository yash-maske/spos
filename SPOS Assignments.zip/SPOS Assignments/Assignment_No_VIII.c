#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_SYMBOLS 50
#define MAX_LINE_LEN 100
#define MAX_OPCODE_LEN 10

// Define a structure for the symbol table
typedef struct {
    char symbol[MAX_OPCODE_LEN];
    int address;
} Symbol;

// Define a structure for the intermediate code
typedef struct {
    char opcode[MAX_OPCODE_LEN];
    char operand[MAX_OPCODE_LEN];
} IntermediateCode;

// Global variables
Symbol symbolTable[MAX_SYMBOLS];
IntermediateCode intermediateCode[MAX_SYMBOLS];
int symbolCount = 0;
int intermediateCount = 0;
int locationCounter = 0;

// Function to add a symbol to the symbol table
void addSymbol(char *symbol) {
    strcpy(symbolTable[symbolCount].symbol, symbol);
    symbolTable[symbolCount].address = locationCounter;
    symbolCount++;
}

// Function to add intermediate code
void addIntermediateCode(char *opcode, char *operand) {
    strcpy(intermediateCode[intermediateCount].opcode, opcode);
    strcpy(intermediateCode[intermediateCount].operand, operand);
    intermediateCount++;
}

// Function to process the source file (Pass-I)
void processSourceFile(FILE *sourceFile) {
    char line[MAX_LINE_LEN];
    char label[MAX_OPCODE_LEN], opcode[MAX_OPCODE_LEN], operand[MAX_OPCODE_LEN];
    
    while (fgets(line, sizeof(line), sourceFile) != NULL) {
        // Ignore comments (lines starting with ;)
        if (line[0] == ';' || line[0] == '\n') continue;
        
        // Reset the label, opcode, and operand
        memset(label, 0, sizeof(label));
        memset(opcode, 0, sizeof(opcode));
        memset(operand, 0, sizeof(operand));
        
        // Parse the label (if any)
        if (line[0] != ' ' && line[0] != '\t') {
            sscanf(line, "%s", label);
            locationCounter++;  // Increment the location counter if label exists
        }
        
        // Parse the opcode and operand
        if (sscanf(line, "%s %s", opcode, operand) > 0) {
            if (label[0] != '\0') {
                addSymbol(label);  // Add label to the symbol table
            }
            
            addIntermediateCode(opcode, operand);  // Add instruction to intermediate code
            locationCounter++;  // Increment LC for each instruction
        }
    }
}

// Function to display the symbol table
void displaySymbolTable() {
    printf("\nSymbol Table:\n");
    printf("Symbol\t\tAddress\n");
    for (int i = 0; i < symbolCount; i++) {
        printf("%s\t\t%d\n", symbolTable[i].symbol, symbolTable[i].address);
    }
}

// Function to display the intermediate code
void displayIntermediateCode() {
    printf("\nIntermediate Code:\n");
    printf("Opcode\t\tOperand\n");
    for (int i = 0; i < intermediateCount; i++) {
        printf("%s\t\t%s\n", intermediateCode[i].opcode, intermediateCode[i].operand);
    }
}

int main() {
    char fileName[100];
    
    // Ask the user for the source file name
    printf("Enter the source file name: ");
    scanf("%s", fileName);
    
    FILE *sourceFile = fopen(fileName, "r");
    
    if (sourceFile == NULL) {
        printf("Error opening file.\n");
        return 1;
    }
    
    // Process the source file to generate symbol table and intermediate code
    processSourceFile(sourceFile);
    
    // Display the symbol table
    displaySymbolTable();
    
    // Display the intermediate code
    displayIntermediateCode();
    
    fclose(sourceFile);
    return 0;
}
