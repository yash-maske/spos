#include <stdio.h>
#include <stdbool.h>

#define MAX 10

int n, m; // n = number of processes, m = number of resources
int alloc[MAX][MAX], max[MAX][MAX], need[MAX][MAX], avail[MAX];

void calculateNeed() {
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            need[i][j] = max[i][j] - alloc[i][j];
}

bool isSafe() {
    int work[MAX], finish[MAX] = {0}, safeSeq[MAX], count = 0;

    for (int i = 0; i < m; i++)
        work[i] = avail[i];

    while (count < n) {
        bool found = false;
        for (int p = 0; p < n; p++) {
            if (!finish[p]) {
                int j;
                for (j = 0; j < m; j++)
                    if (need[p][j] > work[j])
                        break;

                if (j == m) {
                    for (int k = 0; k < m; k++)
                        work[k] += alloc[p][k];
                    safeSeq[count++] = p;
                    finish[p] = 1;
                    found = true;
                }
            }
        }
        if (!found) {
            printf("\nSystem is NOT in a safe state.\n");
            return false;
        }
    }

    printf("\nSystem is in a SAFE state.\nSafe sequence: ");
    for (int i = 0; i < n; i++)
        printf("P%d ", safeSeq[i]);
    printf("\n");

    return true;
}

void requestResources() {
    int p, req[MAX];
    printf("\nEnter process number (0 to %d): ", n - 1);
    scanf("%d", &p);
    printf("Enter request for each resource:\n");
    for (int i = 0; i < m; i++)
        scanf("%d", &req[i]);

    for (int i = 0; i < m; i++) {
        if (req[i] > need[p][i]) {
            printf("Error: Request exceeds maximum claim.\n");
            return;
        }
        if (req[i] > avail[i]) {
            printf("Resources not available. Process must wait.\n");
            return;
        }
    }

    // Pretend allocation
    for (int i = 0; i < m; i++) {
        avail[i] -= req[i];
        alloc[p][i] += req[i];
        need[p][i] -= req[i];
    }

    if (isSafe()) {
        printf("Request granted.\n");
    } else {
        // Rollback
        for (int i = 0; i < m; i++) {
            avail[i] += req[i];
            alloc[p][i] -= req[i];
            need[p][i] += req[i];
        }
        printf("Request cannot be granted. Rolled back.\n");
    }
}

int main() {
    printf("Enter number of processes: ");
    scanf("%d", &n);
    printf("Enter number of resources: ");
    scanf("%d", &m);

    printf("\nEnter allocation matrix:\n");
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            scanf("%d", &alloc[i][j]);

    printf("\nEnter maximum matrix:\n");
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            scanf("%d", &max[i][j]);

    printf("\nEnter available resources:\n");
    for (int i = 0; i < m; i++)
        scanf("%d", &avail[i]);

    calculateNeed();

    int choice;
    do {
        printf("\nBanker's Algorithm Menu:\n");
        printf("1. Check System Safety\n");
        printf("2. Request Resources\n");
        printf("3. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                isSafe();
                break;
            case 2:
                requestResources();
                break;
            case 3:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice!\n");
        }

    } while (choice != 3);

    return 0;
}
