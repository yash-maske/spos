#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define BUFFER_SIZE 1024

int main() {
    int fd[2]; // fd[0] - read end, fd[1] - write end
    pid_t pid;
    char path[BUFFER_SIZE];
    char buffer[BUFFER_SIZE];

    // Create a pipe
    if (pipe(fd) == -1) {
        perror("Pipe failed");
        return 1;
    }

    printf("Enter full path of the text file: ");
    fgets(path, sizeof(path), stdin);
    path[strcspn(path, "\n")] = '\0'; // Remove newline

    pid = fork();

    if (pid < 0) {
        perror("Fork failed");
        return 1;
    }

    else if (pid == 0) {
        // Child process
        close(fd[0]); // Close unused read end

        // Redirect stdout to pipe
        dup2(fd[1], STDOUT_FILENO);
        close(fd[1]);

        // Use 'wc' command to count lines, words, characters
        execlp("wc", "wc", path, NULL);

        // If execlp fails
        perror("execlp failed");
        exit(1);
    }

    else {
        // Parent process
        close(fd[1]); // Close unused write end

      

        // Read output from pipe
        read(fd[0], buffer, sizeof(buffer));
        printf("\nFile statistics (lines, words, characters):\n%s", buffer);

        close(fd[0]);
    }

    return 0;
}
