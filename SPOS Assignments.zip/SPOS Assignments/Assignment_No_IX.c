#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_SYMBOLS 50
#define MAX_OPCODE_LEN 10
#define MAX_LINE_LEN 100

// Structure for the symbol table
typedef struct {
    char symbol[MAX_OPCODE_LEN];
    int address;
} Symbol;

// Structure for the intermediate code
typedef struct {
    char opcode[MAX_OPCODE_LEN];
    char operand[MAX_OPCODE_LEN];
} IntermediateCode;

// Global variables for the symbol table and intermediate code
Symbol symbolTable[MAX_SYMBOLS];
IntermediateCode intermediateCode[MAX_SYMBOLS];
int symbolCount = 0;
int intermediateCount = 0;

// Function to load the symbol table from the file (output of Pass-I)
void loadSymbolTable(FILE *symbolFile) {
    while (fscanf(symbolFile, "%s %d", symbolTable[symbolCount].symbol, &symbolTable[symbolCount].address) != EOF) {
        symbolCount++;
    }
}

// Function to load the intermediate code from the file (output of Pass-I)
void loadIntermediateCode(FILE *intermediateFile) {
    while (fscanf(intermediateFile, "%s %s", intermediateCode[intermediateCount].opcode, intermediateCode[intermediateCount].operand) != EOF) {
        intermediateCount++;
    }
}

// Function to translate the opcode to machine code (pseudo-code in this case)
void translateOpcode(char *opcode, char *machineCode) {
    if (strcmp(opcode, "LOAD") == 0) {
        strcpy(machineCode, "0001");
    } else if (strcmp(opcode, "ADD") == 0) {
        strcpy(machineCode, "0010");
    } else if (strcmp(opcode, "STORE") == 0) {
        strcpy(machineCode, "0011");
    } else if (strcmp(opcode, "END") == 0) {
        strcpy(machineCode, "1111");
    } else {
        strcpy(machineCode, "XXXX");  // Undefined opcode
    }
}

// Function to generate the machine code based on intermediate code and symbol table
void generateMachineCode(FILE *outputFile) {
    for (int i = 0; i < intermediateCount; i++) {
        char machineCode[MAX_OPCODE_LEN + 10];  // Holds the complete machine code
        char operandAddress[MAX_OPCODE_LEN];
        int addressFound = 0;

        // Translate opcode to machine code
        translateOpcode(intermediateCode[i].opcode, machineCode);

        // If the operand is a label, replace it with the corresponding address from the symbol table
        for (int j = 0; j < symbolCount; j++) {
            if (strcmp(intermediateCode[i].operand, symbolTable[j].symbol) == 0) {
                sprintf(operandAddress, "%d", symbolTable[j].address);
                addressFound = 1;
                break;
            }
        }

        if (!addressFound) {
            strcpy(operandAddress, intermediateCode[i].operand);  // If no label, use the operand as is
        }

        // Write the generated machine code to the output file
        fprintf(outputFile, "%s %s\n", machineCode, operandAddress);
    }
}

int main() {
    char symbolFileName[100], intermediateFileName[100], outputFileName[100];

    // Ask the user for the filenames of the symbol table and intermediate code files from Pass-I
    printf("Enter the symbol table file name (Pass-I output): ");
    scanf("%s", symbolFileName);

    printf("Enter the intermediate code file name (Pass-I output): ");
    scanf("%s", intermediateFileName);

    printf("Enter the output machine code file name: ");
    scanf("%s", outputFileName);

    // Open the files
    FILE *symbolFile = fopen(symbolFileName, "r");
    if (symbolFile == NULL) {
        printf("Error opening symbol table file.\n");
        return 1;
    }

    FILE *intermediateFile = fopen(intermediateFileName, "r");
    if (intermediateFile == NULL) {
        printf("Error opening intermediate code file.\n");
        return 1;
    }

    FILE *outputFile = fopen(outputFileName, "w");
    if (outputFile == NULL) {
        printf("Error opening output file.\n");
        return 1;
    }

    // Load the symbol table and intermediate code from Pass-I
    loadSymbolTable(symbolFile);
    loadIntermediateCode(intermediateFile);

    // Generate the machine code
    generateMachineCode(outputFile);

    // Close all the files
    fclose(symbolFile);
    fclose(intermediateFile);
    fclose(outputFile);

    printf("Machine code has been generated successfully in '%s'.\n", outputFileName);
    return 0;
}
